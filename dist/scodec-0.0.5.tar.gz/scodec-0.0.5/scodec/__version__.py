# -*- coding: utf-8 -*-
VERSION = (0, 0, 5)

__version__ = '.'.join(map(str, VERSION))
