"""
Spatial Codec __init___
===================================

Logger initialization for spatial codec

Copyright © 2021 LEAP. All Rights Reserved.
"""

# execute logger config
from scodec.logs.config import config

config()
