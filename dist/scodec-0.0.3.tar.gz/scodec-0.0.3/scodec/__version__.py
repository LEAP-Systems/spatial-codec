# -*- coding: utf-8 -*-
VERSION = (0, 0, 3)

__version__ = '.'.join(map(str, VERSION))
